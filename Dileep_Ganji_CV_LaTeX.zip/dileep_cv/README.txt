Dileep Ganji - LaTeX CV
========================
Main file: main.tex

Contact:
Phone: 7676637747
Email: hgdileepganji@gmail.com
LinkedIn: https://www.linkedin.com/in/h-g-dileep-ganji-952a50396
GitHub: https://github.com/hgdileepganji-art
Location: Bellari, Karnataka, India
Expected graduation: 2029

Compile with pdflatex main.tex (or use Overleaf).
